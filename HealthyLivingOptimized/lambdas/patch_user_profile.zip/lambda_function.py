import pymysql
import boto3
import os
import uuid
import json

endpoint = str(os.environ['endpoint'])
user = str(os.environ['user'])
dbname = str(os.environ['dbname'])
password = str(os.environ['password'])

conn =  pymysql.connect(endpoint, user=user, passwd=password, db=dbname)
table_id = uuid.uuid4()

def lambda_handler(event, context):
	# email = event['email']
	try:
	    cur = conn.cursor()
	    sql = "UPDATE BodyMetrics SET Email = %s, Age = %s, Weight = %s, Height_in_inches = %s WHERE Email = %s"
	    val = (event['email'], event['age'], event['weight'], event['heightInInches'], event['email'])
	    cur.execute(sql, val)
	    cur.execute("SELECT * FROM BodyMetrics WHERE Email = 'alexislarson@gmail.com'")
	    query_results = cur.fetchall()
	    conn.commit()
	    return(query_results)
	except Exception as e:
	    return("Database connection failed due to {}".format(e))          