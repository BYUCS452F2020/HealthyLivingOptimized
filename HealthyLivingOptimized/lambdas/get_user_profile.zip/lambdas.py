import pymysql
import boto3
import os

endpoint = str(os.environ['endpoint'])
user = str(os.environ['user'])
dbname = str(os.environ['dbname'])
password = str(os.environ['password'])

conn =  pymysql.connect(endpoint, user=user, passwd=password, db=dbname)

def get_user_profile(event, context):
	print(event)
	email = event['email']
	try:
		params = [
			'email', 
			'firstName', 
			'lastName', 
			'gender', 
			'age', 
			'weight', 
			'heightInInches', 
			email
		]
		
		sql = "SELECT U.Email %s, U.First_name %s, U.Last_name %s, U.Gender %s, B.Age %s, B.Weight %s, B.Height_in_inches %s FROM User U JOIN BodyMetrics B ON U.Email = B.Email WHERE U.Email = %s"
		
		dict_cur = pymysql.cursors.DictCursor(conn)
		dict_cur.execute(sql, params)
		profile = dict_cur.fetchall()
		conn.commit()
		return(profile[0])
	except Exception as e:
	    return({"error": "Database connection failed due to {}".format(e)})          