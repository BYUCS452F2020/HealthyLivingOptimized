import pymysql
import boto3
import os
import uuid
import json

endpoint = str(os.environ['endpoint'])
user = str(os.environ['user'])
dbname = str(os.environ['dbname'])
password = str(os.environ['password'])


conn =  pymysql.connect(endpoint, user=user, passwd=password, db=dbname)

def lambda_handler(event, context):
	try:
		cur = conn.cursor()
		
		sql = "INSERT INTO LifestyleStats (Stats_id, Email, Date, Hours_of_sleep, Grams_of_protein, Type_of_exercise, Minutes_of_exercise, Current_weight, Mood, Muscle_growth) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
		id = str(uuid.uuid4())
		val = (id, event['email'], event['date'], event['hoursOfSleep'], event['gramsOfProtein'], event['typeOfExercise'], event['minutesOfExercise'], event['currentWeight'], event['mood'], event['muscleGrowth'])
		
		cur.execute(sql, val)
		conn.commit()
		
		return ({"success": "Successfully added event with id: {}".format(id)})
	
	except Exception as e:
		return({"error" : "Database connection failed due to {}".format(e)})          