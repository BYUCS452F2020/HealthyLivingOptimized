const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient({region: 'us-east-1', apiVersion: '2012-08-10'});

exports.handler = async (event) => {
    
    let email = event.email;
    let entryId = event.entryId;
    
    var fileItem = {
    Key: {
      key: email,
      sort: entryId
    },
    TableName: 'DailyEntry',
    };

    try {
        let data = await dynamodb.delete(fileItem).promise();
        return 'data';
    } catch (err) {
        return 'error';
    }
};
