import pymysql
import boto3
import os
import uuid
import json
import datetime

endpoint = str(os.environ['endpoint'])
user = str(os.environ['user'])
dbname = str(os.environ['dbname'])
password = str(os.environ['password'])

conn =  pymysql.connect(endpoint, user=user, passwd=password, db=dbname)
table_id = uuid.uuid4()

import datetime
from json import JSONEncoder

class DateTimeEncoder(JSONEncoder):
        #Override the default method
        def default(self, obj):
            if isinstance(obj, (datetime.date, datetime.datetime)):
            	return obj.isoformat()

def lambda_handler(event, context):
	email = event['email']
	try:
		dict_cur = pymysql.cursors.DictCursor(conn)
		lifestyle_params = ['date', 'hoursOfSleep', 'gramsOfProtein', 'typeOfExercise', 'minutesOfExercise', 'currentWeight', 'mood', 'muscleGrowth', email]
		lifestyle_sql = "SELECT Stats_id entryId, Date date, Hours_of_sleep hoursOfSleep, Grams_of_protein gramsOfProtein, Type_of_exercise typeOfExercise, Minutes_of_exercise minutesOfExercise, Current_weight currentWeight, Mood mood, Muscle_growth muscleGrowth FROM LifestyleStats WHERE Email = %s"
		dict_cur.execute(lifestyle_sql, email)
		report_history = dict_cur.fetchall()
		report = json.dumps(report_history, cls = DateTimeEncoder)
		conn.commit()
		return json.loads(report)
	except Exception as e:
	    return("Database connection failed due to {}".format(e))          