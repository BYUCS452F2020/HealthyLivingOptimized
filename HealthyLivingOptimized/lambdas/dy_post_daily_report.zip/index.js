const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient({region: 'us-east-1', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    
    let sort = context.awsRequestId;
    // Part 1
    const params = {
        ReturnConsumedCapacity: "TOTAL",
        TableName: "DailyEntry",
        Item: {
            
            "key": event.email,
            "sort": sort,
            "entryId": sort,
            "date": event.date,
            "hoursOfSleep": event.hoursOfSleep,
            "gramsOfProtein": event.gramsOfProtein,
            "typeOfExercise": event.typeOfExercise,
            "minutesOfExercise": event.minutesOfExercise,
            "currentWeight": event.currentWeight,
            "mood": event.mood,
            "muscleGrowth": event.muscleGrowth
        }
    };
    
    dynamodb.put(params, function(err, data) {
        if (err) {
            // console.log(err);
            callback(err);
        } else {
            callback(null, {"success": "Successfuly added"});
        }
    });
};
