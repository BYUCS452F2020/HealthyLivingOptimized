const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient({region: 'us-east-1', apiVersion: '2012-08-10'});

exports.handler = async (event) => {
    
    let username = event.email;
    
    const params = {
        TableName: "Users",
        
        Key: {
                "key": username,
        }
    };

    try {
        let data = await dynamodb.get(params).promise();
        if (data.Item) return data.Item;
        else return "Not able to find a profile";
    
    } catch(err) {
        return err;
    }
    
};
