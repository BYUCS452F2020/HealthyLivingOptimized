const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient({region: 'us-east-1', apiVersion: '2012-08-10'});

exports.handler = async (event) => {
    
    // Get query values
    const email = event.email;
    
    const params = {
        TableName: "DailyEntry",
        ScanIndexForward: false, //accomplishes most recent
        Limit: 20,
        
        KeyConditionExpression: "#key = :key",
        
        ExpressionAttributeValues: {
            ":key": email
        },
        
        ExpressionAttributeNames: {
            "#key": "key"
        }
    };
    
    try {
        let data = await dynamodb.query(params).promise();
        return data.Items;
    
    } catch(err) {
        return err;
    }
    
    // return event.major;
};


