const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({region: 'us-east-1', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    
    // Get info from user parameters
    const firstName = event.request.clientMetadata['firstName'];
    const lastName = event.request.clientMetadata['lastName'];
    const email = event.request.clientMetadata['email'];
    
    const weight = event.request.clientMetadata['weight'];
    const height = event.request.clientMetadata['height'];
    const age = event.request.clientMetadata['age'];
    const gender = event.request.clientMetadata['gender'];
    const goal = event.request.clientMetadata['goal'];
    const goalWeight = event.request.clientMetadata['goalWeight'];
    
    // Create 
    const info = {
        Item: {
            "key": { S: email },
            "firstName": { S: firstName },
            "lastName": { S: lastName },
            "email": { S: email },
            
            "weight": { N: weight },
            "height": { N: height },
            "age": { N: age },
            "gender": { S: gender },
            "goal": { S: goal },
            "goalWeight": { N: goalWeight }
            
        },
        ReturnConsumedCapacity: "TOTAL",
        TableName: "Users"
    };
    
    // Send to dynamo
    dynamodb.putItem(info, function(err, data) {
        if (err) {
            console.log(err);
            callback(err);
        } else {
            console.log(data);
            callback(null, event);
        }
    });
    
    // callback(null, event);
};
