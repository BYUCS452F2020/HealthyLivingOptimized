import pymysql
import os
import uuid

endpoint = str(os.environ['endpoint'])
user = str(os.environ['user'])
dbname = str(os.environ['dbname'])
password = str(os.environ['password'])

conn =  pymysql.connect(endpoint, user=user, passwd=password, db=dbname)       

def lambda_handler(event, context):
	metadata = event['request']['clientMetadata']
	try:
		cur = conn.cursor()
		firstName = metadata['firstName']
		lastName = metadata['lastName']
		email = metadata['email']
		weight = metadata['weight']
		height = metadata['height']
		age = metadata['age']
		gender = metadata['gender']
		goal = metadata['goal']
		goalWeight = metadata['goalWeight']
	    
	    # Populate the SQL Tables: Users, BodyMetrics and Goals
	
	    # User: Need to update this with Gender
		sql1 = "INSERT INTO User VALUES (%s, %s, %s, %s)"
		vals = (email, firstName, lastName, gender)
		cur.execute(sql1, vals)
	
		# BodyMetrics
		metric_id = str(uuid.uuid4())
		sql2 = "INSERT INTO BodyMetrics VALUES (%s, %s, %s, %s, %s)"
		vals = (metric_id, email, age, weight, height)
		cur.execute(sql2, vals)
	
	    # Goals
		goal_id = str(uuid.uuid4())
		sql3 = "INSERT INTO Goals VALUES (%s, %s, %s, %s)"
		vals = (goal_id, email, goal, goalWeight)
		cur.execute(sql3, vals)
		conn.commit()
		
		return event

	except Exception as e:
		return({"error": "Database connection failed due to {}".format(e)})