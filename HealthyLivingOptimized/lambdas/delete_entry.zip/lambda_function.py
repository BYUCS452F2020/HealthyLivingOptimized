import pymysql
import os
import uuid

endpoint = str(os.environ['endpoint'])
user = str(os.environ['user'])
dbname = str(os.environ['dbname'])
password = str(os.environ['password'])

conn =  pymysql.connect(endpoint, user=user, passwd=password, db=dbname)       

def lambda_handler(event, context):
	try:
		cur = conn.cursor()
		entry_id = event['entryId']
		
		sql_start = "SELECT * FROM LifestyleStats WHERE Stats_id = '{}'".format(entry_id)
		cur.execute(sql_start)
		print("Select query:", sql_start)
		result = cur.fetchall()
		
		sql = "DELETE FROM LifestyleStats WHERE Stats_id = '{}'".format(entry_id)
		print("Delete query:", sql)
		cur.execute(sql)
		
		if len(result) == 0:
			return {"error" : "Delete failed for entry_id: {}. Event does not exist".format(entry_id)}
		
		sql_verify = "SELECT * FROM LifestyleStats WHERE Stats_id = '{}'".format(entry_id)
		cur.execute(sql_verify)
		
		result = cur.fetchall()
		print("Result:")
		print(result)
		
		conn.commit()
		
		return ({"success" : "Successfully deleted entry with id: {}".format(entry_id)})
		
	except Exception as e:
		return({"error": "Database connection failed due to {}".format(e)})